from django.contrib import admin

# Register your models here.
from.models import registration
from.models import login
admin.site.register(registration)
admin.site.register(login)