from django.shortcuts import render
from.models import login
from.models import registration

def home1(request):
    return render(request,'home.html')
def usregister(request):
    return render(request,'register.html')
def userreg(request):
    first_name=request.POST['fname']
    last_name=request.POST['lname']
    email=request.POST['mail']
    password=request.POST['pass']
    data=registration(First_name=first_name,Last_name=last_name,Email=email,Password=password,Status=0)
    data.save()

    data1=login(Email=email,Password=password,Status=1)
    data1.save()
    return render(request,'home.html')
def adm(request):
    return render(request,'adminreg.html')
def adreg(request):
    email = request.POST['mail']
    password = request.POST['pass']
    data2 = registration( Email=email, Password=password,Status=2)
    data2.save()
    return render(request, 'home.html')
def ulogin(request):
    return render(request,'login.html')
def log(request):
     lg=login.objects.get(Email=request.POST['mail'],Password=request.POST['pass'],)

     if lg.Status==2:
        request.session['member_id'] = lg.Email
        data2=registration.objects.all()
        return render(request,'adminview.html',{'data2':data2})

     elif lg.Status==1:
        request.session['member_id']=lg.Email
        return render(request,'final.html')


def update(request):
    id = request.POST['id']
    registration.objects.filter(id=id).update(status=0)
    data2 = registration.objects.filter(status=1)
    return render(request, 'newone.html', {'data2': data2})
