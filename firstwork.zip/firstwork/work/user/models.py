from django.db import models

# Create your models here.
class registration(models.Model):
    First_name=models.CharField(max_length=50)
    Last_name=models.CharField(max_length=50)
    Email=models.CharField(max_length=50)
    Password=models.IntegerField()

class login(models.Model):
    Email = models.CharField(max_length=50)
    Password = models.IntegerField()
    Status = models.IntegerField()